package com.cts.booking.entity;

public class Customer {	

	//write code for the Customer entity class. 
	//Create Many-to Many association relationship between Customer and Event entity and 
	// hence add the collection properties accordingly
	protected int custId;

	protected String custName;

	protected String custAddress;

}
