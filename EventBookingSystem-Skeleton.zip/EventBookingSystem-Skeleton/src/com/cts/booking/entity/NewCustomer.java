package com.cts.booking.entity;

public class NewCustomer extends Customer {
//This clas would adopt the inheritance strategy	
}
